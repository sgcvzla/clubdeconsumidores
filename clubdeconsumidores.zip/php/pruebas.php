<?php
echo "<pre>";
	var_dump($_SERVER);
	echo "<br/>";
	echo dirname();
	echo "<br/>";
	echo basename();
	echo "<br/>";
	echo pathinfo();
echo "</pre>";
?>
