<?php 
$urlOrdenesPagadas = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders.json?financial_status=paid';

$urlUnaOrden = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders/';

$urlOrdenesPendientes = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders.json?financial_status=pending';

$urlOrdenesParcialmentePagadas = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders.json?financial_status=partially_paid';

$urlTransaccionesUnaOrden = "https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders/1839940239434/transactions.json";

$urlBuscarTransaccion = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders/';

$urlBuscarProducto = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/products/';

$urlOrdenMetafields = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/orders/';

$urlUnCustomer = 'https://060d3f560e548b08d411633144ae09fb:44e7bd60350b8ad36bc0f899930ad51e@anatie.myshopify.com/admin/api/2019-10/customers/';

$urlTienda = 'anatie.myshopify.com';
$KeyTienda = '060d3f560e548b08d411633144ae09fb';
$SecretTienda = '9eab1dc9805a64405c3ce49c56ff5e62';

$user_zoom = "1";
$pass_zoom = "456789";
$priv_zoom = "RH0sVTL9za7O6gutqI43";
?>
